import React, { useEffect, useState } from 'react';
import { Row, Col, Button, message } from 'antd';
import { useNavigate } from 'react-router-dom';
import UserCard from '../components/UserCard';
import EditUserModal from '../components/EditUserModal';
import Loader from '../components/Loader';
import api from '../utils/api'; // Axios instance

const Dashboard = () => {
  const [users, setUsers] = useState([]); 
  const [editingUser, setEditingUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await api.get('/users');
        console.log("Fetched users:", response.data.users);
  
        // Simulate slow network (remove this in production)
        await new Promise(resolve => setTimeout(resolve, 2000)); 
  
        setUsers(response.data.users);
      } catch (error) {
        console.error('Error fetching user data', error);
        message.error('Failed to load user data');
      } finally {
        setLoading(false); // Loader hides after delay
      }
    };
  
    fetchUserData();
  }, []);
  
  const handleEdit = (user) => {
    setEditingUser(user);
  };

  const handleSave = (updatedUser) => {
    setUsers(prev => prev.map(u => (u.id === updatedUser.id ? updatedUser : u)));
    setEditingUser(null);
  };

  const handleDelete = (id) => {
    setUsers(prev => prev.filter(user => user.id !== id));
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/');
  };

  if (loading) return <Loader />;

  return (
    <div>
      <div style={{ padding: 20, textAlign: 'right' }}>
        <Button onClick={handleLogout} type="primary" danger>
          Logout
        </Button>
      </div>

      <Row gutter={[16, 16]} justify="center">
        {users.map(user => (
          <Col key={user.id}>
            <UserCard
              user={user}
              onEdit={handleEdit}
              onDelete={handleDelete}
            />
          </Col>
        ))}
      </Row>

      <EditUserModal
        visible={!!editingUser}
        user={editingUser}
        onSave={handleSave}
        onCancel={() => setEditingUser(null)}
      />
    </div>
  );
};

export default Dashboard;
