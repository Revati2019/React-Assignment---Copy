import React from 'react';
import { Card, Avatar, Button } from 'antd';
import { EditOutlined, DeleteOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';

const { Meta } = Card;

const UserCard = ({ user, onEdit, onDelete }) => {
  const navigate = useNavigate();

  const handleCardClick = () => {
    navigate(`/user/${user.id}`);
  };

  return (
    <Card
      style={{ width: 300, margin: 10, cursor: 'pointer' }}
      onClick={handleCardClick}
      actions={[
        <EditOutlined
          key="edit"
          onClick={(e) => {
            e.stopPropagation(); // prevent card navigation
            onEdit(user);
          }}
        />,
        <DeleteOutlined
          key="delete"
          onClick={(e) => {
            e.stopPropagation(); // prevent card navigation
            onDelete(user.id);
          }}
        />
      ]}
    >
      <Meta
        avatar={
          <Avatar src={`https://avatars.dicebear.com/v2/avataaars/${user.username}.svg?options[mood][]=happy`} />
        }
        title={user.name}
        description={
          <>
            <div><b>Email:</b> {user.email}</div>
            <div><b>Phone:</b> {user.phone}</div>
            <div><b>Address:</b> {`${user.address.street}, ${user.address.city}`}</div>
            <div><b>Website:</b> {user.website}</div>
            <div><b>Company:</b> {user.company.name}</div>
          </>
        }
      />
    </Card>
  );
};

export default UserCard;
