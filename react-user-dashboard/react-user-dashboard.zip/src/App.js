// import React from 'react';
// import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
// import { Layout } from 'antd';
// import Dashboard from './pages/Dashboard';
// import LoginPage from './pages/LoginPage';
// import NotFound from './pages/NotFound';
// import ProtectedRoute from './components/ProtectedRoute';

// const App = () => {
//   return (
//     <Router>
//       <Layout>
//         <Routes>
//           <Route path="/" element={<LoginPage />} />
          
//           {/* Protect the Dashboard Route */}
//           <Route path="/dashboard" element={<ProtectedRoute component={Dashboard} />} />
          
//           {/* Add other routes here */}
//           <Route path="*" element={<NotFound />} />
//         </Routes>
//       </Layout>
//     </Router>
//   );
// };

// export default App;
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { Layout } from 'antd';
import Dashboard from './pages/Dashboard';
import LoginPage from './pages/LoginPage';
import NotFound from './pages/NotFound';
import ProtectedRoute from './components/ProtectedRoute';
import UserProfile from './pages/UserProfile'; // Import the new User Profile page

const App = () => {
  return (
    <Router>
      <Layout>
        <Routes>
          {/* Public route */}
          <Route path="/" element={<LoginPage />} />

          {/* Protected routes */}
          <Route path="/dashboard" element={<ProtectedRoute component={Dashboard} />} />
          <Route path="/user/:id" element={<ProtectedRoute component={UserProfile} />} />

          {/* 404 fallback */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Layout>
    </Router>
  );
};

export default App;

